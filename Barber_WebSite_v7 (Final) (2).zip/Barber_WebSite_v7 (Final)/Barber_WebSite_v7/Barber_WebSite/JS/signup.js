import { auth, db } from './Firebase.js';
import { createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import { doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
  // Select the signup form from the DOM
  const signupForm = document.getElementById('signup-form');

  // Check if form exists
  if (!signupForm) {
    console.error('Signup form not found!');
    return;
  }

  // Listen for form submission
  signupForm.addEventListener('submit', async (e) => {
    e.preventDefault(); // Prevent default form submission

    // FIXED: Use querySelector to get values by name attribute
    const firstname = signupForm.querySelector('[name="firstname"]').value.trim();
    const lastname = signupForm.querySelector('[name="lastname"]').value.trim();
    const email = signupForm.querySelector('[name="email"]').value.trim();
    const phoneNumber = signupForm.querySelector('[name="phoneNumber"]').value.trim();
    const dateOfBirth = signupForm.querySelector('[name="dateOfBirth"]').value;
    const password = signupForm.querySelector('[name="password"]').value;
    const confirmPassword = signupForm.querySelector('[name="confirm_password"]').value;

    // Validate password match
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    // Validate password strength
    if (password.length < 8 || password.length > 20) {
      alert("Password must be between 8 and 20 characters.");
      return;
    }

    // Optional: require at least one uppercase letter and one number
    const pattern = /^(?=.*[A-Z])(?=.*\d).+$/;
    if (!pattern.test(password)) {
      alert("Password must include at least one uppercase letter and one number.");
      return;
    }

    // Generate readable userID: initials + YYYYMMDD of DOB
    const initials = firstname.charAt(0).toUpperCase() + lastname.charAt(0).toUpperCase();
    const dobFormatted = dateOfBirth.replace(/-/g, ""); // 1988-05-31 -> 19880531
    const userID = `${initials}${dobFormatted}`;

    try {
      // 1️⃣ Create user in Firebase Authentication
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const uid = userCredential.user.uid; // Firebase UID (still used internally)

      // 2️⃣ Store user information in Firestore
      await setDoc(doc(db, "users", uid), {
        userID: userID,       // readable user ID
        firstname: firstname,
        lastname: lastname,
        email: email,
        phoneNumber: phoneNumber,
        passwordHash: "",      // Firebase handles password securely
        role: "Customer",      // Default role
        dateOfBirth: dateOfBirth,
        createdAt: serverTimestamp()
      });

      alert("Account created successfully!");
      signupForm.reset();
      window.location.href = "login.html"; // Redirect to login page

    } catch (error) {
      console.error("Error creating account:", error);
      alert(`Error: ${error.message}`);
    }
  });
});