import { db } from "./Firebase.js";
import { collection, getDocs, query, orderBy, where } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const tableBody = document.getElementById("appointments-body");
const noAppointmentsMsg = document.getElementById("no-appointments-msg");

async function loadAppointments() {
    if (!tableBody) return;

    try {
        const q = query(
            collection(db, "appointments"), 
            orderBy("appointmentDate")
        );
        const querySnapshot = await getDocs(q);
        
        if (querySnapshot.empty) {
            noAppointmentsMsg.style.display = "block";
            return;
        }

        noAppointmentsMsg.style.display = "none";
        tableBody.innerHTML = "";

        const appointments = [];
        
        querySnapshot.forEach((doc) => {
            // FILTER OUT THE SCHEMA DOCUMENT
            if (doc.id === "_schema") return;
            
            const data = doc.data();
            
            // Only add documents that have appointment data
            if (data.appointmentDate || data.appointmentID) {
                appointments.push({
                    id: data.appointmentID || doc.id,
                    customer: data.customerName ? data.customerName : 
                             data.childName ? `${data.childName} ${data.childSurname || ''}`.trim() : "N/A",
                    barber: data.barber || "N/A",
                    date: data.appointmentDate || "N/A",
                    time: data.appointmentTime || "",
                    service: data.serviceName || data.haircut || "N/A",
                    status: data.status || "N/A",
                    rawDate: data.appointmentDate,
                    rawTime: data.appointmentTime
                });
            }
        });

        // If no real appointments after filtering
        if (appointments.length === 0) {
            noAppointmentsMsg.style.display = "block";
            return;
        }

        // Manual sorting
        appointments.sort((a, b) => {
            if (a.rawDate < b.rawDate) return -1;
            if (a.rawDate > b.rawDate) return 1;
            if (a.rawTime < b.rawTime) return -1;
            if (a.rawTime > b.rawTime) return 1;
            return 0;
        });

        // Populate table
        appointments.forEach(appointment => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${appointment.id}</td>
                <td>${appointment.customer}</td>
                <td>${appointment.barber}</td>
                <td>${appointment.date} ${appointment.time}</td>
                <td>${appointment.service}</td>
                <td>${appointment.status}</td>
            `;
            tableBody.appendChild(row);
        });

    } catch (error) {
        console.error("Error loading appointments:", error);
        tableBody.innerHTML = `<tr><td colspan="6">Error loading data</td></tr>`;
    }
}

document.addEventListener('DOMContentLoaded', loadAppointments);