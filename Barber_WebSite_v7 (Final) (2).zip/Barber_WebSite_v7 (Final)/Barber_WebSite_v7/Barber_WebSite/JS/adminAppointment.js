import { db } from "./Firebase.js";
import { 
    collection, 
    getDocs, 
    query, 
    orderBy,
    updateDoc,
    doc,
    where,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const tableBody = document.getElementById('firebase-appointments-body');

// Load all appointments from Firebase
async function loadAppointments() {
    try {
        const appointmentsRef = collection(db, "appointments");
        const q = query(appointmentsRef);
        const snapshot = await getDocs(q);
        
        tableBody.innerHTML = "";
        
        if (snapshot.empty) {
            tableBody.innerHTML = '<tr><td colspan="7">No appointments found</td></tr>';
            return;
        }

        snapshot.forEach((docSnap) => {
            // FILTER OUT SCHEMA DOCUMENT
            if (docSnap.id === "_schema") return;
            
            const data = docSnap.data();
            
            // Only process documents with appointment data
            if (data.appointmentDate || data.appointmentID) {
                createAppointmentRow(docSnap.id, data);
            }
        });

    } catch (error) {
        console.error("Error loading appointments:", error);
        tableBody.innerHTML = '<tr><td colspan="7">Error loading appointments</td></tr>';
    }
}

// Create table row for appointment
function createAppointmentRow(docId, data) {
    // Handle customer name (adult vs child)
    let customer = "N/A";
    if (data.customerName) {
        customer = data.customerName;
    } else if (data.childName) {
        customer = `${data.childName} ${data.childSurname || ''}`.trim();
    }

    // Handle service name
    let service = "N/A";
    if (data.serviceName) {
        service = data.serviceName;
    } else if (data.haircut) {
        service = data.haircut;
    }

    const dateTime = `${data.appointmentDate || "N/A"} ${data.appointmentTime || ""}`;
    const status = data.status || "Booked";
    
    // Check if actions should be disabled
    const isCompleted = status === "Completed";
    const isCancelled = status === "Cancelled";
    const showActions = !isCompleted && !isCancelled;

    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td>${data.appointmentID || docId}</td>
        <td>${customer}</td>
        <td>${data.barber || "N/A"}</td>
        <td>${dateTime}</td>
        <td>${service}</td>
        <td>${status}</td>
        <td>
            ${showActions ? `
                <button class="action-btn" onclick="firebaseReschedule('${docId}')">Reschedule</button>
                <button class="action-btn" onclick="firebaseComplete('${docId}')">Complete</button>
            ` : '<span style="color: #999;">No actions</span>'}
        </td>
    `;
    
    tableBody.appendChild(tr);

    // Only add reschedule form for appointments that can be rescheduled
    if (showActions) {
        const formRow = document.createElement('tr');
        formRow.innerHTML = `
            <td colspan="7">
                <div class="reschedule-form" id="reschedule-form-${docId}" style="display: none;">
                    <label>New Date & Time:</label>
                    <input type="date" id="new-date-${docId}" />
                    <input type="time" id="new-time-${docId}" />
                    <button onclick="firebaseSaveReschedule('${docId}')">Save</button>
                    <button onclick="firebaseToggleReschedule('${docId}')">Cancel</button>
                </div>
            </td>
        `;
        tableBody.appendChild(formRow);
    }
}

// Firebase functions with different names to avoid conflicts
window.firebaseToggleReschedule = function(docId) {
    const form = document.getElementById(`reschedule-form-${docId}`);
    form.style.display = form.style.display === 'block' ? 'none' : 'block';
}

window.firebaseSaveReschedule = async function(docId) {
    const newDate = document.getElementById(`new-date-${docId}`).value;
    const newTime = document.getElementById(`new-time-${docId}`).value;

    if (!newDate || !newTime) {
        alert('Please select both date and time');
        return;
    }

    try {
        const appointmentDoc = await getDoc(doc(db, "appointments", docId));
        const appointmentData = appointmentDoc.data();
        
        // Don't allow rescheduling of completed/cancelled appointments
        if (appointmentData.status === "Completed" || appointmentData.status === "Cancelled") {
            alert('Cannot reschedule completed or cancelled appointments');
            return;
        }
        
        const appointmentsRef = collection(db, "appointments");
        const conflictQuery = query(
            appointmentsRef,
            where("barber", "==", appointmentData.barber),
            where("appointmentDate", "==", newDate),
            where("appointmentTime", "==", newTime),
            where("location", "==", appointmentData.location)
        );
        
        const conflictSnapshot = await getDocs(conflictQuery);
        if (!conflictSnapshot.empty && conflictSnapshot.docs[0].id !== docId) {
            alert('This time slot is already booked for the barber!');
            return;
        }

        await updateDoc(doc(db, "appointments", docId), {
            appointmentDate: newDate,
            appointmentTime: newTime,
            status: "Rescheduled",
            updatedAt: new Date()
        });

        alert('Appointment rescheduled successfully!');
        loadAppointments();

    } catch (error) {
        console.error("Error rescheduling appointment:", error);
        alert('Error rescheduling appointment');
    }
}

window.firebaseComplete = async function(docId) {
    if (!confirm('Mark this appointment as completed?')) return;

    try {
        const appointmentDoc = await getDoc(doc(db, "appointments", docId));
        const appointmentData = appointmentDoc.data();
        
        // Don't allow completing cancelled appointments
        if (appointmentData.status === "Cancelled") {
            alert('Cannot complete a cancelled appointment');
            return;
        }

        await updateDoc(doc(db, "appointments", docId), {
            status: "Completed",
            updatedAt: new Date()
        });

        alert('Appointment marked as completed!');
        loadAppointments();

    } catch (error) {
        console.error("Error completing appointment:", error);
        alert('Error marking appointment as complete');
    }
}

// Load appointments when page loads
document.addEventListener('DOMContentLoaded', loadAppointments);