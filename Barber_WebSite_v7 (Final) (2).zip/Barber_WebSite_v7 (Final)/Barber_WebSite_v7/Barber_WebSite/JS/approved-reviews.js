import { db } from "./Firebase.js";
import { 
    collection, 
    getDocs
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const reviewsContainer = document.getElementById('approvedReviewsContainer');

// Load approved reviews - SIMPLIFIED VERSION
async function loadApprovedReviews() {
    try {
        console.log("🔄 Loading all reviews...");
        
        const reviewsRef = collection(db, "reviews");
        const snapshot = await getDocs(reviewsRef);
        
        console.log("✅ Found", snapshot.size, "total reviews");
        
        // Filter approved reviews manually
        const approvedReviews = [];
        snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            console.log("Review:", data);
            if (data.status === "approved") {
                approvedReviews.push({ id: docSnap.id, ...data });
            }
        });
        
        console.log("✅ Approved reviews:", approvedReviews.length);
        displayReviews(approvedReviews);
        
    } catch (error) {
        console.error("❌ Error:", error);
        reviewsContainer.innerHTML = '<p style="text-align: center;">Error loading reviews: ' + error.message + '</p>';
    }
}

// Display approved reviews
function displayReviews(reviews) {
    reviewsContainer.innerHTML = '';
    
    if (reviews.length === 0) {
        reviewsContainer.innerHTML = '<p style="text-align: center;">No approved reviews yet. Check back soon!</p>';
        return;
    }

    reviews.forEach((review) => {
        const reviewDiv = document.createElement('div');
        reviewDiv.className = 'review-item';
        
        // Format date
        const reviewDate = review.createdAt ? review.createdAt.toDate().toLocaleDateString() : 'Recent';
        
        // Create star rating
        const stars = '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating);
        
        reviewDiv.innerHTML = `
            <div class="review-header">
                <div class="reviewer-name">${review.userName}</div>
                <div class="review-date">${reviewDate}</div>
            </div>
            <div class="review-barber">${review.barber || 'General Service'}</div>
            <div class="review-stars">${stars}</div>
            <div class="review-comment">"${review.comment}"</div>
        `;
        
        reviewsContainer.appendChild(reviewDiv);
    });
}

// Load reviews when page opens
document.addEventListener('DOMContentLoaded', loadApprovedReviews);