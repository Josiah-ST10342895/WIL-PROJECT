import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import { getFirestore, doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyAUHTPkJ63XQj2RUEn_-HbKKuoEUa9RrFM",
  authDomain: "tupac-unisex-salon-database.firebaseapp.com",
  projectId: "tupac-unisex-salon-database",
  storageBucket: "tupac-unisex-salon-database.appspot.com",
  messagingSenderId: "282620817236",
  appId: "1:282620817236:web:b13f13e237a59de7cfe2c1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Setup function to structure Firestore
async function setupFirestoreStructure() {
  try {
    // Define initial empty documents that reflect each table schema
    const baseDocuments = {
      users: {
        userID: "",
        firstname: "",
        lastname: "",
        email: "",
        phoneNumber: "",
        passwordHash: "",
        role: "",
        dateOfBirth: "",
        createdAt: serverTimestamp()
      },
      services: {
        serviceID: "",
        name: "",
        description: "",
        duration_min: 0,
        price: 0
      },
      appointments: {
        appointmentID: "",
        userID: "",
        serviceID: "",
        appointmentDate: "",
        appointmentTime: "",
        status: "",
        createdAt: serverTimestamp()
      },
      childBookings: {
        childBookingID: "",
        appointmentID: "",
        childFirstname: "",
        childLastname: "",
        dateOfBirth: ""
      },
      payments: {
        paymentID: "",
        appointmentID: "",
        amount: 0,
        status: "",
        paymentDate: serverTimestamp()
      },
      ai_chathistory: {
        chatID: "",
        userID: "",
        role: "",
        timestamp: serverTimestamp(),
        cust_message: "",
        aiResponse: ""
      },
      products: {
        productID: "",
        name: "",
        description: "",
        price: 0,
        stockQuantity: 0
      }
    };

    // Create a sample “schema reference” doc inside each collection
    for (const [collectionName, structure] of Object.entries(baseDocuments)) {
      await setDoc(doc(db, collectionName, "_schema"), structure);
    }

    console.log("Firestore schema setup complete!");

   
    await Promise.all([addSampleServices(), addSampleProducts()]);
    
  } catch (error) {
    console.error("Error setting up Firestore schema:", error);
  }
}

// Sample Services
async function addSampleServices() {
  const sampleServices = [
    { serviceID: "1", name: "Haircut", description: "Professional haircut and styling", duration_min: 45, price: 25.00 },
    { serviceID: "2", name: "Hair Coloring", description: "Full hair coloring service", duration_min: 120, price: 80.00 }
  ];

  await Promise.all(sampleServices.map(service =>
    setDoc(doc(db, "services", service.serviceID), service)
  ));

  console.log("✅ Sample services added");
}

// Sample Products
async function addSampleProducts() {
  const sampleProducts = [
    { productID: "1", name: "Shampoo", description: "Luxury moisturizing shampoo", price: 15.00, stockQuantity: 50 },
    { productID: "2", name: "Hair Gel", description: "Strong hold styling gel", price: 10.00, stockQuantity: 100 }
  ];

  await Promise.all(sampleProducts.map(product =>
    setDoc(doc(db, "products", product.productID), product)
  ));

  console.log("✅ Sample products added");
}

// Run setup once
setupFirestoreStructure();

export { app, db, auth };
