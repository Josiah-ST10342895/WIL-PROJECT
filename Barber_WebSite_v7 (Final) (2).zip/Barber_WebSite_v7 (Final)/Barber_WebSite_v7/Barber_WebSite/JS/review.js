import { auth, db } from "./firebase.js";
import { collection, addDoc, doc, getDoc, query, where, getDocs } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";

const reviewForm = document.querySelector('.review-form');
const fname = document.getElementById('fname');
const email = document.getElementById('email');
const barberSelect = document.getElementById('barberSelect');
const ratingValue = document.getElementById('ratingValue');
const reason = document.getElementById('reason');

let selectedRating = 0;
let currentUser = null;

// Star rating logic
const stars = document.querySelectorAll('.star-rating .star');
stars.forEach((star, idx) => {
    star.addEventListener('mouseover', () => {
        for (let i = 0; i < stars.length; i++) {
            stars[i].classList.toggle('hover', i <= idx);
        }
    });
    star.addEventListener('mouseout', () => {
        for (let i = 0; i < stars.length; i++) {
            stars[i].classList.remove('hover');
        }
    });
    star.addEventListener('click', () => {
        selectedRating = idx + 1;
        ratingValue.value = selectedRating;
        for (let i = 0; i < stars.length; i++) {
            stars[i].classList.toggle('selected', i < selectedRating);
        }
    });
});

// Function to get user data from Firestore
async function getUserData(userId) {
    try {
        const userDoc = await getDoc(doc(db, "users", userId));
        if (userDoc.exists()) {
            return userDoc.data();
        }
        return null;
    } catch (error) {
        console.error("Error getting user data:", error);
        return null;
    }
}

// Function to get user's appointments and barbers
async function getUserAppointments(userId) {
    try {
        const appointmentsRef = collection(db, "appointments");
        const q = query(
            appointmentsRef, 
            where("userID", "==", userId)
        );
        
        const snap = await getDocs(q);
        return snap.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
    } catch (error) {
        console.error("Error getting user appointments:", error);
        return [];
    }
}

// Function to get unique barbers from appointments
function getUniqueBarbers(appointments) {
    const barbers = [...new Set(appointments.map(apt => apt.barber))];
    return barbers.filter(barber => barber); // Remove any empty/null values
}

// Check authentication state and verify appointments
onAuthStateChanged(auth, async (user) => {
    currentUser = user;
    
    if (user) {
        // User is logged in - get their data and appointments
        const userData = await getUserData(user.uid);
        const userAppointments = await getUserAppointments(user.uid);
        
        // Auto-fill user details
        if (userData) {
            if (userData.firstname) {
                fname.value = userData.firstname;
            }
            if (userData.email) {
                email.value = userData.email;
            }
        } else {
            // If no user data in Firestore, use auth email
            if (user.email) {
                email.value = user.email;
            }
        }
        
        // Make name and email fields read-only
        fname.readOnly = true;
        email.readOnly = true;
        
        // Check if user has any appointments
        if (userAppointments.length === 0) {
            // No appointments - disable form and show message
            reviewForm.style.opacity = "0.6";
            reviewForm.querySelectorAll('input, select, textarea, button').forEach(element => {
                element.disabled = true;
            });
            
            const message = document.createElement('p');
            message.style.color = 'red';
            message.style.textAlign = 'center';
            message.style.marginTop = '20px';
            message.style.fontWeight = 'bold';
            message.innerHTML = 'You need to book an appointment before leaving a review. <br><a href="booking_type.html" style="color: blue; text-decoration: underline;">Book Now</a>';
            reviewForm.appendChild(message);
            
        } else {
            // User has appointments - populate barber dropdown with their barbers
            const userBarbers = getUniqueBarbers(userAppointments);
            
            if (userBarbers.length > 0) {
                barberSelect.innerHTML = '<option value="">Select Barber</option>';
                userBarbers.forEach(barber => {
                    const option = document.createElement('option');
                    option.value = barber;
                    option.textContent = barber;
                    barberSelect.appendChild(option);
                });
            }
            
            // Form is enabled and ready to use
            reviewForm.style.opacity = "1";
            reviewForm.querySelectorAll('input, select, textarea, button').forEach(element => {
                element.disabled = false;
            });
        }
        
    } else {
        // User is not logged in - reset form
        fname.readOnly = false;
        email.readOnly = false;
        fname.value = "";
        email.value = "";
        barberSelect.innerHTML = '<option value="">Select Barber</option>';
        reviewForm.style.opacity = "1";
        reviewForm.querySelectorAll('input, select, textarea, button').forEach(element => {
            element.disabled = false;
        });
        
        // Remove any existing message
        const existingMessage = reviewForm.querySelector('p');
        if (existingMessage) {
            existingMessage.remove();
        }
    }
});

// Handle form submission
reviewForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    // Check if user is logged in
    if (!currentUser) {
        alert('Please login to submit a review.');
        window.location.href = 'login.html';
        return;
    }

    // Double-check user has appointments
    const userAppointments = await getUserAppointments(currentUser.uid);
    if (userAppointments.length === 0) {
        alert('You need to book an appointment before leaving a review.');
        window.location.href = 'booking_type.html';
        return;
    }

    const firstName = fname.value.trim();
    const userEmail = email.value.trim();
    const barber = barberSelect.value;
    const rating = parseInt(ratingValue.value);
    const comment = reason.value.trim();

    // Validation
    if (!firstName) {
        alert('Please enter your first name.');
        fname.focus();
        return;
    }
    if (!userEmail) {
        alert('Please enter your email.');
        email.focus();
        return;
    }
    if (!/\S+@\S+\.\S+/.test(userEmail)) {
        alert('Please enter a valid email address.');
        email.focus();
        return;
    }
    if (!barber) {
        alert('Please select a barber.');
        barberSelect.focus();
        return;
    }
    if (rating === 0) {
        alert('Please select a rating.');
        return;
    }
    if (!comment) {
        alert('Please enter your review comment.');
        reason.focus();
        return;
    }

    try {
        // Save review to Firestore
        await addDoc(collection(db, "reviews"), {
            userId: currentUser.uid,
            userName: firstName,
            userEmail: userEmail,
            barber: barber,
            rating: rating,
            comment: comment,
            status: "pending",
            createdAt: new Date()
        });

        alert('Thank you for your review! It has been submitted for approval.');
        
        // Clear form but keep user details
        barberSelect.value = "";
        ratingValue.value = 0;
        reason.value = "";
        selectedRating = 0;
        stars.forEach(star => star.classList.remove('selected'));
        
    } catch (error) {
        console.error("Error submitting review:", error);
        alert('Error submitting review. Please try again.');
    }
});