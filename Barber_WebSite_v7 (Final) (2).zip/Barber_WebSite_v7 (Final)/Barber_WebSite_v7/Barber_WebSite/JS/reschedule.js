import { db, auth } from "./Firebase.js";
import { collection, query, where, getDocs, updateDoc, doc, orderBy } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

// DOM Elements
const loadingElement = document.getElementById("loading");
const currentAppointmentsSection = document.getElementById("current-appointments-section");
const pastAppointmentsSection = document.getElementById("past-appointments-section");
const noAppointmentsElement = document.getElementById("no-appointments");
const currentAppointmentsBody = document.getElementById("current-appointments-body");
const pastAppointmentsBody = document.getElementById("past-appointments-body");
const rescheduleModal = document.getElementById("reschedule-modal");
const dateInput = document.getElementById("date");
const timeSelect = document.getElementById("time");
const rescheduleForm = document.getElementById("reschedule-form");
const cancelRescheduleBtn = document.getElementById("cancel-reschedule");

let currentEditingAppointment = null;

function generateTimes() {
  const times = [];
  for (let hour = 9; hour <= 17; hour++) {
    times.push(`${hour.toString().padStart(2,"0")}:00`);
    times.push(`${hour.toString().padStart(2,"0")}:30`);
  }
  return times;
}

async function updateAvailableTimes(date, barber, location, currentTime) {
  const appointmentsRef = collection(db, "appointments");
  
  // Simplified query without composite index requirements
  const q = query(
    appointmentsRef,
    where("barber", "==", barber),
    where("appointmentDate", "==", date),
    where("location", "==", location)
  );

  try {
    const snap = await getDocs(q);
    const bookedTimes = snap.docs
      .filter(d => d.id !== currentEditingAppointment?.id)
      .map(doc => {
        const data = doc.data();
        // Only consider appointments that are not cancelled
        return (data.status === "Booked" || data.status === "Rescheduled") ? data.appointmentTime : null;
      })
      .filter(time => time !== null);

    timeSelect.innerHTML = '<option value="">Select a time</option>';
    const allTimes = generateTimes();
    allTimes.forEach(t => {
      const option = document.createElement("option");
      option.value = t;
      option.textContent = bookedTimes.includes(t) ? `${t} (Booked)` : t;
      if (bookedTimes.includes(t)) option.disabled = true;
      timeSelect.appendChild(option);
    });

    // Preselect current time if available
    if (currentTime && !bookedTimes.includes(currentTime)) {
      timeSelect.value = currentTime;
    }
  } catch (error) {
    console.error("Error updating available times:", error);
    // If there's an error, just show all times without booking info
    timeSelect.innerHTML = '<option value="">Select a time</option>';
    generateTimes().forEach(t => {
      const option = document.createElement("option");
      option.value = t;
      option.textContent = t;
      timeSelect.appendChild(option);
    });
  }
}

// Load user appointments automatically - SIMPLIFIED QUERY
async function loadUserAppointments(userId) {
  try {
    loadingElement.style.display = "block";
    currentAppointmentsSection.style.display = "none";
    pastAppointmentsSection.style.display = "none";
    noAppointmentsElement.style.display = "none";

    const appointmentsRef = collection(db, "appointments");
    
    // SIMPLIFIED: Only filter by userID to avoid index requirements
    const q = query(
      appointmentsRef, 
      where("userID", "==", userId)
      // Removed orderBy to avoid composite index requirement
    );

    const snap = await getDocs(q);

    if (snap.empty) {
      loadingElement.style.display = "none";
      noAppointmentsElement.style.display = "block";
      return;
    }

    // Clear existing tables
    currentAppointmentsBody.innerHTML = "";
    pastAppointmentsBody.innerHTML = "";

    let hasCurrentAppointments = false;
    let hasPastAppointments = false;

    // Sort manually in JavaScript instead of using Firestore orderBy
    const appointments = snap.docs.map(doc => {
      const data = doc.data();
      return {
        ...data,
        id: doc.id,
        // Create a sortable date string for manual sorting
        sortDate: data.appointmentDate + data.appointmentTime
      };
    });

    // Sort by date and time manually (newest first)
    appointments.sort((a, b) => b.sortDate.localeCompare(a.sortDate));

    appointments.forEach(appointment => {
      const row = createAppointmentRow(appointment);
      
      if (appointment.status === "Booked" || appointment.status === "Rescheduled") {
        currentAppointmentsBody.appendChild(row);
        hasCurrentAppointments = true;
      } else if (appointment.status === "Completed" || appointment.status === "Cancelled") {
        pastAppointmentsBody.appendChild(row);
        hasPastAppointments = true;
      }
    });

    loadingElement.style.display = "none";
    
    if (hasCurrentAppointments) {
      currentAppointmentsSection.style.display = "block";
    }
    
    if (hasPastAppointments) {
      pastAppointmentsSection.style.display = "block";
    }

    if (!hasCurrentAppointments && !hasPastAppointments) {
      noAppointmentsElement.style.display = "block";
    }

  } catch (error) {
    console.error("Error loading appointments:", error);
    loadingElement.style.display = "none";
    
    // More specific error message
    if (error.code === 'failed-precondition') {
      alert("Database configuration issue. Please try again later.");
    } else {
      alert("Error loading appointments. Please try again.");
    }
  }
}

function createAppointmentRow(appointment) {
  const row = document.createElement("tr");
  
  // Format date for display
  const appointmentDate = new Date(appointment.appointmentDate + 'T00:00:00');
  const formattedDate = appointmentDate.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });

  row.innerHTML = `
    <td>${appointment.appointmentID}</td>
    <td>${formattedDate}</td>
    <td>${appointment.appointmentTime}</td>
    <td>${appointment.serviceName || appointment.serviceType || 'Hair Service'}</td>
    <td>${appointment.barber}</td>
    <td>${appointment.location}</td>
    ${(appointment.status === "Booked" || appointment.status === "Rescheduled") ? 
      `<td>
        <button class="reschedule-btn" data-id="${appointment.id}">Reschedule</button>
        <button class="cancel-btn" data-id="${appointment.id}">Cancel</button>
      </td>` : 
      `<td>${appointment.status}</td>`
    }
  `;

  // Add event listeners for action buttons
  if (appointment.status === "Booked" || appointment.status === "Rescheduled") {
    const rescheduleBtn = row.querySelector('.reschedule-btn');
    const cancelBtn = row.querySelector('.cancel-btn');
    
    rescheduleBtn.addEventListener('click', () => openRescheduleModal(appointment));
    cancelBtn.addEventListener('click', () => cancelAppointment(appointment.id, appointment.appointmentID));
  }

  return row;
}

function openRescheduleModal(appointment) {
  currentEditingAppointment = appointment;
  dateInput.value = appointment.appointmentDate;
  dateInput.min = new Date().toISOString().split('T')[0]; // Set min date to today
  
  updateAvailableTimes(
    appointment.appointmentDate, 
    appointment.barber, 
    appointment.location, 
    appointment.appointmentTime
  );
  
  rescheduleModal.style.display = "block";
}

// Reschedule form submission
rescheduleForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!currentEditingAppointment) return;

  const newDate = dateInput.value;
  const newTime = timeSelect.value;
  if (!newDate || !newTime) return alert("Select a date and time");

  try {
    // Conflict check with simplified query
    const appointmentsRef = collection(db, "appointments");
    const q = query(
      appointmentsRef,
      where("barber", "==", currentEditingAppointment.barber),
      where("appointmentDate", "==", newDate),
      where("appointmentTime", "==", newTime),
      where("location", "==", currentEditingAppointment.location)
    );

    const snap = await getDocs(q);
    const conflictingAppointments = snap.docs.filter(doc => {
      const data = doc.data();
      return doc.id !== currentEditingAppointment.id && 
             (data.status === "Booked" || data.status === "Rescheduled");
    });

    if (conflictingAppointments.length > 0) {
      alert("Time already booked! Choose another.");
      updateAvailableTimes(newDate, currentEditingAppointment.barber, currentEditingAppointment.location);
      return;
    }

    // Update Firestore
    await updateDoc(doc(db, "appointments", currentEditingAppointment.id), {
      appointmentDate: newDate,
      appointmentTime: newTime,
      status: "Rescheduled"
    });
    
    alert(`✅ Appointment rescheduled to ${newDate} at ${newTime}`);
    rescheduleModal.style.display = "none";
    window.location.reload();
  } catch (err) {
    console.error(err);
    alert("❌ Failed to reschedule. Try again.");
  }
});

// Cancel appointment function
async function cancelAppointment(docId, appointmentId) {
  if (!confirm(`Are you sure you want to cancel appointment ${appointmentId}?`)) return;

  try {
    await updateDoc(doc(db, "appointments", docId), {
      status: "Cancelled"
    });
    alert("✅ Appointment cancelled successfully");
    window.location.reload();
  } catch (err) {
    console.error(err);
    alert("❌ Failed to cancel. Try again.");
  }
}

// Update times when date changes in modal
dateInput.addEventListener("change", () => {
  if (currentEditingAppointment) {
    updateAvailableTimes(
      dateInput.value, 
      currentEditingAppointment.barber, 
      currentEditingAppointment.location
    );
  }
});

// Close modal
cancelRescheduleBtn.addEventListener("click", () => {
  rescheduleModal.style.display = "none";
  currentEditingAppointment = null;
});

// Close modal when clicking outside
window.addEventListener("click", (e) => {
  if (e.target === rescheduleModal) {
    rescheduleModal.style.display = "none";
    currentEditingAppointment = null;
  }
});

// Initialize when page loads and user is authenticated
auth.onAuthStateChanged((user) => {
  if (user) {
    loadUserAppointments(user.uid);
  } else {
    loadingElement.style.display = "none";
    noAppointmentsElement.innerHTML = `
      <p>Please log in to view your appointments.</p>
      <a href="signup.html" class="btn">Login/Sign Up</a>
    `;
    noAppointmentsElement.style.display = "block";
  }
});