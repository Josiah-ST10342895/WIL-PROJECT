import { auth, db } from "./Firebase.js";
import { 
    collection, 
    addDoc, 
    query, 
    where, 
    getDocs,
    serverTimestamp 
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";

class ChatBot {
    constructor() {
        this.messages = document.getElementById('messages');
        this.userInput = document.getElementById('user-input');
        this.sendButton = document.getElementById('send-button');
        this.chatBubble = document.getElementById('chat-bubble');
        this.chatWidget = document.getElementById('chatbot-widget');
        this.closeChat = document.getElementById('close-chat');
        this.currentUser = null;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.checkAuthState();
    }

    setupEventListeners() {
        // Chat toggle
        this.chatBubble.addEventListener('click', () => this.openChat());
        this.closeChat.addEventListener('click', () => this.closeChatWindow());

        // Message sending
        this.sendButton.addEventListener('click', () => this.sendMessage());
        this.userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });
    }

    checkAuthState() {
        onAuthStateChanged(auth, (user) => {
            this.currentUser = user;
            // If user logs in while chat is open, load their history
            if (user && this.chatWidget.style.display === 'flex') {
                this.loadChatHistory(user.uid);
            }
        });
    }

    openChat() {
        this.chatWidget.style.display = 'flex';
        this.chatBubble.style.display = 'none';
        
        // Clear previous messages
        this.messages.innerHTML = '';
        
        // Show personalized message for logged-in users, generic for guests
        if (this.currentUser) {
            this.loadChatHistory(this.currentUser.uid);
        } else {
            this.appendMessage('bot', 'Hello! Welcome to Tupac Unisex Salon! How can I assist you today?');
        }
    }

    closeChatWindow() {
        this.chatWidget.style.display = 'none';
        this.chatBubble.style.display = 'flex';
    }

    async sendMessage() {
        const userMessage = this.userInput.value.trim();
        if (!userMessage) return;

        // Add user message to chat
        this.appendMessage('user', userMessage);
        this.userInput.value = '';

        // Save user message to Firebase (only for logged-in users)
        if (this.currentUser) {
            await this.saveMessageToFirebase('user', userMessage);
        }

        // Get and display bot response
        setTimeout(async () => {
            const botResponse = this.getBotResponse(userMessage);
            this.appendMessage('bot', botResponse);

            // Save bot response to Firebase (only for logged-in users)
            if (this.currentUser) {
                await this.saveMessageToFirebase('bot', botResponse);
            }
        }, 500);
    }

    appendMessage(sender, text) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', sender);
        messageDiv.textContent = text;
        this.messages.appendChild(messageDiv);
        this.messages.scrollTop = this.messages.scrollHeight;
    }

    getBotResponse(userMessage) {
        const message = userMessage.toLowerCase();
        
        // Personalized greeting for logged-in users
        if ((message.includes('hello') || message.includes('hi')) && this.currentUser) {
            const userName = JSON.parse(localStorage.getItem('loggedInUser'))?.name || 'there';
            return `Hello ${userName}! Welcome back to Tupac Unisex Salon! How can I assist you today?`;
        }
        
        if (message.includes('hello') || message.includes('hi')) {
            return 'Hello! Welcome to Tupac Unisex Salon! How can I assist you today?';
        } else if (message.includes('services')) {
            return 'We offer haircuts, shaves, coloring, and styling for both men and women.';
        } else if (message.includes('hours') || message.includes('open')) {
            return 'We are open from 9 AM to 7 PM, Monday to Saturday.';
        } else if (message.includes('location')) {
            return 'We are located at Market St and Kerk St, Vryheid. Visit us for more details!';
        } else if (message.includes('price') || message.includes('cost')) {
            return 'Let me redirect you to our prices page where you can see all service costs.';
        } else if (message.includes('appointment') || message.includes('book')) {
            return 'I can take you to our booking page where you can choose your service and barber!';
        } else if (message.includes('cancel') || message.includes('cancellation')) {
            return 'We require 24-hour notice for cancellations. Less than 24 hours may incur a 25% fee.';
        } else if (message.includes('child') || message.includes('kid') || message.includes('children')) {
            return 'Children under 16 must be accompanied by a parent or guardian for all services.';
        } else if (message.includes('payment') || message.includes('pay') || message.includes('card') || message.includes('cash')) {
            return 'We accept cash, credit cards, and mobile payments like Zapper/SnapScan.';
        } else if (message.includes('emergency') || message.includes('urgent') || message.includes('contact')) {
            return 'For urgent matters, please call us directly at (034) 123-4567.';
        } else if (message.includes('login') || message.includes('sign up')) {
            return 'You can create an account or login to book appointments and manage your reservations!';
        } else {
            return 'I\'m sorry, I didn\'t understand that. Can you please rephrase?';
        }
    }

    async saveMessageToFirebase(role, message) {
        try {
            await addDoc(collection(db, "ai_chathistory"), {
                userID: this.currentUser.uid,
                role: role,
                timestamp: serverTimestamp(),
                cust_message: role === 'user' ? message : '',
                aiResponse: role === 'bot' ? message : ''
            });
        } catch (error) {
            console.error("Error saving message to Firebase:", error);
        }
    }

    async loadChatHistory(userId) {
        try {
            const q = query(
                collection(db, "ai_chathistory"),
                where("userID", "==", userId)
                // Removed orderBy to avoid index requirement
            );
            
            const snapshot = await getDocs(q);
            this.messages.innerHTML = ''; // Clear current messages

            if (snapshot.empty) {
                // Show personalized welcome for logged-in users with no history
                const userName = JSON.parse(localStorage.getItem('loggedInUser'))?.name || 'there';
                this.appendMessage('bot', `Hello ${userName}! Welcome to Tupac Unisex Salon! How can I assist you today?`);
                return;
            }

            // Sort messages manually in JavaScript (by timestamp if available)
            const messages = [];
            snapshot.forEach((doc) => {
                const data = doc.data();
                messages.push({
                    ...data,
                    id: doc.id,
                    timestamp: data.timestamp?.toDate?.() || new Date(0) // Fallback to epoch if no timestamp
                });
            });

            // Sort by timestamp (oldest first)
            messages.sort((a, b) => a.timestamp - b.timestamp);

            // Display sorted messages
            messages.forEach((data) => {
                if (data.cust_message && data.cust_message.trim() !== '') {
                    this.appendMessage('user', data.cust_message);
                }
                if (data.aiResponse && data.aiResponse.trim() !== '') {
                    this.appendMessage('bot', data.aiResponse);
                }
            });

        } catch (error) {
            console.error("Error loading chat history:", error);
            // Fallback welcome message
            const userName = this.currentUser ? 
                (JSON.parse(localStorage.getItem('loggedInUser'))?.name || 'there') : 
                '';
            
            const welcomeMessage = this.currentUser ? 
                `Hello ${userName}! Welcome to Tupac Unisex Salon! How can I assist you today?` :
                'Hello! Welcome to Tupac Unisex Salon! How can I assist you today?';
            
            this.appendMessage('bot', welcomeMessage);
        }
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ChatBot();
});