import { db } from "./Firebase.js";
import { 
    collection, 
    getDocs, 
    addDoc, 
    query, 
    where, 
    orderBy 
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const addRecordBtn = document.getElementById('addRecordBtn');
const summaryBody = document.getElementById('summaryBody');
let currentViewDate = new Date();

// Load and display records for current month
async function loadRecordsForMonth() {
    try {
        const recordsRef = collection(db, "records");
        const startOfMonth = new Date(currentViewDate.getFullYear(), currentViewDate.getMonth(), 1);
        const endOfMonth = new Date(currentViewDate.getFullYear(), currentViewDate.getMonth() + 1, 0);
        
        const q = query(
            recordsRef, 
            where("date", ">=", startOfMonth.toISOString().split('T')[0]),
            where("date", "<=", endOfMonth.toISOString().split('T')[0]),
            orderBy("date", "desc")
        );
        
        const snapshot = await getDocs(q);
        displayRecords(snapshot);
        
    } catch (error) {
        console.error("Error loading records:", error);
        summaryBody.innerHTML = '<tr><td colspan="3">Error loading records</td></tr>';
    }
}

// Display records in table
function displayRecords(snapshot) {
    summaryBody.innerHTML = '';
    
    if (snapshot.empty) {
        summaryBody.innerHTML = '<tr><td colspan="3">No records found for this month</td></tr>';
        return;
    }

    snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        const tr = document.createElement('tr');
        
        tr.innerHTML = `
            <td>${data.date}</td>
            <td>${data.barber}</td>
            <td>R ${data.amount.toFixed(2)}</td>
        `;
        
        summaryBody.appendChild(tr);
    });
}

// Add new record
addRecordBtn.addEventListener('click', async () => {
    const date = document.getElementById('recordDate').value;
    const barber = document.getElementById('barberName').value;
    const amount = parseFloat(document.getElementById('earningsAmount').value);

    if (!date || !barber || isNaN(amount) || amount <= 0) {
        alert('Please complete all fields with valid data');
        return;
    }

    try {
        await addDoc(collection(db, "records"), {
            date: date,
            barber: barber,
            amount: amount,
            createdAt: new Date()
        });

        alert('Record added successfully!');
        // Clear the form
        document.getElementById('earningsAmount').value = '';
        document.getElementById('recordDate').valueAsDate = new Date();
        // Refresh the table
        loadRecordsForMonth();
        
    } catch (error) {
        console.error("Error adding record:", error);
        alert('Error adding record');
    }
});

// Month navigation
window.changeMonth = function(delta) {
    currentViewDate.setMonth(currentViewDate.getMonth() + delta);
    loadRecordsForMonth();
}

// Load records when page opens
document.addEventListener('DOMContentLoaded', loadRecordsForMonth);