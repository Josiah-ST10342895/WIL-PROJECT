
import { auth, db } from "./firebase.js";
import { signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

// Select the login form
const loginForm = document.getElementById('login-form');

// Listen for form submission
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault(); // Prevent default form submission

  // Get email and password from form
  const email = loginForm.email.value.trim();
  const password = loginForm.password.value;

  try {
    // 1️⃣ Sign in user with Firebase Authentication
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const uid = userCredential.user.uid;

    // 2️⃣ Fetch user document from Firestore
    const userDocRef = doc(db, "users", uid);
    const userDocSnap = await getDoc(userDocRef);

    if (!userDocSnap.exists()) {
      alert("User record not found in database!");
      return;
    }

    const userData = userDocSnap.data();

   
  localStorage.setItem('loggedInUser', JSON.stringify({
  name: userData.firstname,
  role: userData.role
}));

    // 3️⃣ Redirect based on role
    if (userData.role === "Admin") {
      window.location.href = "adminHome.html"; // Admin dashboard
    } else {
      window.location.href = "index.html";     // Regular user homepage
    }

  } catch (error) {
    console.error("Login error:", error);
    alert(`Login failed: ${error.message}`);
  }
});
