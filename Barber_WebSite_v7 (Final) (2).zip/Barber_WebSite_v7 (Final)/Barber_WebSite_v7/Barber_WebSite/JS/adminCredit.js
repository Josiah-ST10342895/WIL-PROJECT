import { db } from "./Firebase.js";
import { 
    collection, 
    getDocs, 
    addDoc, 
    updateDoc,
    deleteDoc,
    doc
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const addCreditBtn = document.getElementById('addCreditBtn');
const creditTableBody = document.getElementById('creditTableBody');

// Load all credits
async function loadCredits() {
    try {
        const creditsRef = collection(db, "credits");
        const snapshot = await getDocs(creditsRef);
        
        displayCredits(snapshot);
        
    } catch (error) {
        console.error("Error loading credits:", error);
        creditTableBody.innerHTML = '<tr><td colspan="6">No credit records yet. Add your first credit above.</td></tr>';
    }
}

// Display credits in table
function displayCredits(snapshot) {
    creditTableBody.innerHTML = '';
    
    if (snapshot.empty) {
        creditTableBody.innerHTML = '<tr><td colspan="6">No credit records found. Add your first credit above.</td></tr>';
        return;
    }

    snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        const tr = document.createElement('tr');
        
        tr.innerHTML = `
            <td>${data.barber}</td>
            <td>R ${data.amount.toFixed(2)}</td>
            <td>${data.dateBorrowed}</td>
            <td>${data.notes || ''}</td>
            <td>${data.status}</td>
            <td>
                <button class="action-btn" onclick="markPaid('${docSnap.id}')" 
                    ${data.status === 'paid' ? 'disabled' : ''}>
                    ${data.status === 'paid' ? 'Paid' : 'Mark Paid'}
                </button>
                <button class="action-btn" onclick="deleteCredit('${docSnap.id}')">Delete</button>
            </td>
        `;
        
        creditTableBody.appendChild(tr);
    });
}

// Add new credit
addCreditBtn.addEventListener('click', async () => {
    const barber = document.getElementById('barber').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const dateBorrowed = document.getElementById('dateBorrowed').value;
    const notes = document.getElementById('notes').value;

    if (!barber || isNaN(amount) || amount <= 0 || !dateBorrowed) {
        alert('Please enter valid data');
        return;
    }

    try {
        await addDoc(collection(db, "credits"), {
            barber: barber,
            amount: amount,
            dateBorrowed: dateBorrowed,
            notes: notes,
            status: "unpaid",
            createdAt: new Date()
        });

        alert('Credit record added successfully!');
        // Clear the form
        document.getElementById('creditForm').reset();
        document.getElementById('dateBorrowed').valueAsDate = new Date();
        // Refresh the table
        loadCredits();
        
    } catch (error) {
        console.error("Error adding credit:", error);
        alert('Error adding credit record');
    }
});

// Mark credit as paid
window.markPaid = async function(docId) {
    if (!confirm('Mark this credit as paid?')) return;

    try {
        await updateDoc(doc(db, "credits", docId), {
            status: "paid"
        });

        alert('Credit marked as paid!');
        loadCredits();
        
    } catch (error) {
        console.error("Error updating credit:", error);
        alert('Error updating credit');
    }
}

// Delete credit
window.deleteCredit = async function(docId) {
    if (!confirm('Delete this credit record?')) return;

    try {
        await deleteDoc(doc(db, "credits", docId));
        alert('Credit record deleted!');
        loadCredits();
        
    } catch (error) {
        console.error("Error deleting credit:", error);
        alert('Error deleting credit');
    }
}

// Load credits when page opens
document.addEventListener('DOMContentLoaded', loadCredits);