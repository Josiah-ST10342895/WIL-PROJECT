// kidGuardian.js
import { db, auth } from "./Firebase.js";
import {
  doc,
  updateDoc,
  serverTimestamp,
  getDoc
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const guardianForm = document.getElementById("guardian-form");

if (guardianForm) {
  guardianForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    // Helper to safely get element value
    const getVal = (id) => {
      const el = document.getElementById(id);
      return el ? el.value.trim() : "";
    };

    // Collect guardian fields
    const gname = getVal("gname");
    const gsurname = getVal("gsurname");
    const gemail = getVal("gemail");
    const gphone = getVal("gphone");
    const gtimeA = getVal("gtimeA");
    const gtimeD = getVal("gtimeD");
    const grelation = getVal("grelation");
    const gallergy = getVal("gallergy") || "None";

    // Validation
    if (!gname || !gsurname || !gemail || !gphone || !grelation) {
      alert("⚠️ Please fill in all required guardian fields.");
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      alert("⚠️ Please log in to submit guardian info.");
      return;
    }

    try {
      const appointmentID = sessionStorage.getItem("appointmentID");
      const childBookingID = sessionStorage.getItem("childBookingID");

      if (!appointmentID || !childBookingID) {
        alert("⚠️ No child booking found. Please start from the booking page.");
        return;
      }

      // Build guardian object
      const guardianObj = {
        name: gname,
        surname: gsurname,
        email: gemail,
        phone: gphone,
        relation: grelation,
        allergy: gallergy
      };
      
      if (gtimeA) guardianObj.arrivalTime = gtimeA;
      if (gtimeD) guardianObj.departureTime = gtimeD;

      // Update ChildBooking with guardian details
      const childBookingRef = doc(db, "childBooking", childBookingID);
      const childBookingSnap = await getDoc(childBookingRef);
      
      if (!childBookingSnap.exists()) {
        alert("⚠️ Child booking not found in database.");
        return;
      }

      await updateDoc(childBookingRef, {
        guardian: guardianObj,
        updatedAt: serverTimestamp()
      });

      // Also update Appointment with basic guardian info for payment page
      const appointmentRef = doc(db, "appointments", appointmentID);
      await updateDoc(appointmentRef, {
        guardianName: `${gname} ${gsurname}`,
        guardianEmail: gemail,
        guardianPhone: gphone,
        updatedAt: serverTimestamp()
      });

      alert("✅ Guardian details saved successfully!");
      
      // Clear session storage
      sessionStorage.removeItem("appointmentID");
      sessionStorage.removeItem("childBookingID");
      sessionStorage.removeItem("childBooking");

      // Redirect to payment page with appointmentID
      window.location.href = `Payment.html?appointmentID=${appointmentID}`;

    } catch (err) {
      console.error("Error saving guardian details:", err);
      alert("❌ Failed to save guardian details. Try again.");
    }
  });
} else {
  console.error("Guardian form not found");
}