import { db } from "./Firebase.js";
import { 
    collection, 
    getDocs, 
    updateDoc,
    deleteDoc,
    doc,
    orderBy,
    query 
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const reviewsTableBody = document.getElementById('reviewsTableBody');
const barberFilter = document.getElementById('barberFilter');
const statusFilter = document.getElementById('statusFilter');

let allReviews = [];

// Load all reviews
async function loadReviews() {
    try {
        const reviewsRef = collection(db, "reviews");
        const q = query(reviewsRef, orderBy("createdAt", "desc"));
        const snapshot = await getDocs(q);
        
        // Store all reviews for filtering
        allReviews = [];
        snapshot.forEach((docSnap) => {
            allReviews.push({
                id: docSnap.id,
                ...docSnap.data()
            });
        });
        
        applyFilters();
        
    } catch (error) {
        console.error("Error loading reviews:", error);
        reviewsTableBody.innerHTML = '<tr><td colspan="7">No reviews found.</td></tr>';
    }
}

// Apply filters to displayed reviews
function applyFilters() {
    const selectedBarber = barberFilter.value;
    const selectedStatus = statusFilter.value;
    
    const filteredReviews = allReviews.filter(review => {
        const barberMatch = selectedBarber === 'all' || review.barber === selectedBarber;
        const statusMatch = selectedStatus === 'all' || review.status === selectedStatus;
        return barberMatch && statusMatch;
    });
    
    displayReviews(filteredReviews);
}

// Display reviews in table
function displayReviews(reviews) {
    reviewsTableBody.innerHTML = '';
    
    if (reviews.length === 0) {
        reviewsTableBody.innerHTML = '<tr><td colspan="7">No reviews match the selected filters.</td></tr>';
        return;
    }

    reviews.forEach((review) => {
        const tr = document.createElement('tr');
        
        // Format date
        const reviewDate = review.createdAt ? review.createdAt.toDate().toISOString().split('T')[0] : 'N/A';
        
        // Create star rating display
        const stars = '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating);
        
        tr.innerHTML = `
            <td>${review.userName}</td>
            <td>${review.barber}</td>
            <td title="${review.rating}/5">${stars}</td>
            <td>${reviewDate}</td>
            <td>${review.comment}</td>
            <td>${review.status}</td>
            <td>
                <button class="action-btn" onclick="approveReview('${review.id}')" 
                    ${review.status === 'approved' ? 'disabled' : ''}>
                    ${review.status === 'approved' ? 'Approved' : 'Approve'}
                </button>
                <button class="action-btn" onclick="deleteReview('${review.id}')">Delete</button>
            </td>
        `;
        
        reviewsTableBody.appendChild(tr);
    });
}

// Approve review
window.approveReview = async function(docId) {
    if (!confirm('Approve this review?')) return;

    try {
        await updateDoc(doc(db, "reviews", docId), {
            status: "approved"
        });

        alert('Review approved!');
        loadReviews(); // Reload to refresh data
        
    } catch (error) {
        console.error("Error approving review:", error);
        alert('Error approving review');
    }
}

// Delete review
window.deleteReview = async function(docId) {
    if (!confirm('Delete this review permanently?')) return;

    try {
        await deleteDoc(doc(db, "reviews", docId));
        alert('Review deleted!');
        loadReviews(); // Reload to refresh data
        
    } catch (error) {
        console.error("Error deleting review:", error);
        alert('Error deleting review');
    }
}

// Filter event listeners
barberFilter.addEventListener('change', applyFilters);
statusFilter.addEventListener('change', applyFilters);

// Load reviews when page opens
document.addEventListener('DOMContentLoaded', loadReviews);