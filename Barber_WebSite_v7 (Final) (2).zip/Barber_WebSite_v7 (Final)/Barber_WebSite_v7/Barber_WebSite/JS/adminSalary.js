import { db } from "./Firebase.js";
import { 
    collection, 
    getDocs, 
    addDoc, 
    updateDoc,
    deleteDoc,
    doc,
    orderBy 
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const calculateBtn = document.getElementById('calculateBtn');
const saveSalaryBtn = document.getElementById('saveSalaryBtn');
const salaryTableBody = document.getElementById('salaryTableBody');

let currentCalculation = null;

// Calculate salary
calculateBtn.addEventListener('click', () => {
    const barber = document.getElementById('barberName').value;
    const period = document.getElementById('period').value;
    const periodDate = document.getElementById('periodDate').value;
    const hoursWorked = parseFloat(document.getElementById('hoursWorked').value);
    const hourlyRate = parseFloat(document.getElementById('hourlyRate').value);
    const commissionPct = parseFloat(document.getElementById('commission').value) / 100;
    const bonuses = parseFloat(document.getElementById('bonuses').value) || 0;
    const deductions = parseFloat(document.getElementById('deductions').value) || 0;

    if (!barber || !periodDate || isNaN(hoursWorked) || isNaN(hourlyRate) || isNaN(commissionPct)) {
        alert('Please fill in all required fields');
        return;
    }

    const baseSalary = hourlyRate * hoursWorked;
    const commissionAmt = baseSalary * commissionPct;
    const totalSalary = baseSalary + commissionAmt + bonuses - deductions;

    // Display results
    document.getElementById('baseSalary').textContent = baseSalary.toFixed(2);
    document.getElementById('commissionAmt').textContent = commissionAmt.toFixed(2);
    document.getElementById('bonusesAmt').textContent = bonuses.toFixed(2);
    document.getElementById('deductionsAmt').textContent = deductions.toFixed(2);
    document.getElementById('totalSalary').textContent = totalSalary.toFixed(2);
    document.getElementById('salaryResult').style.display = 'block';

    // Store calculation for saving
    currentCalculation = {
        barber,
        period,
        periodDate,
        hoursWorked,
        hourlyRate,
        commission: commissionPct * 100,
        baseSalary,
        commissionAmt,
        bonuses,
        deductions,
        totalSalary,
        status: 'unpaid'
    };
});

// Save salary record
saveSalaryBtn.addEventListener('click', async () => {
    if (!currentCalculation) {
        alert('Please calculate salary first');
        return;
    }

    try {
        await addDoc(collection(db, "salaries"), {
            ...currentCalculation,
            createdAt: new Date()
        });

        alert('Salary record saved successfully!');
        document.getElementById('salaryForm').reset();
        document.getElementById('salaryResult').style.display = 'none';
        document.getElementById('periodDate').valueAsDate = new Date();
        currentCalculation = null;
        loadSalaries();
        
    } catch (error) {
        console.error("Error saving salary:", error);
        alert('Error saving salary record');
    }
});

// Load all salaries
async function loadSalaries() {
    try {
        const salariesRef = collection(db, "salaries");
        const snapshot = await getDocs(salariesRef);
        
        displaySalaries(snapshot);
        
    } catch (error) {
        console.error("Error loading salaries:", error);
        salaryTableBody.innerHTML = '<tr><td colspan="8">No salary records yet. Calculate and save your first salary above.</td></tr>';
    }
}

// Display salaries in table
function displaySalaries(snapshot) {
    salaryTableBody.innerHTML = '';
    
    if (snapshot.empty) {
        salaryTableBody.innerHTML = '<tr><td colspan="8">No salary records found.</td></tr>';
        return;
    }

    snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        const tr = document.createElement('tr');
        
        tr.innerHTML = `
            <td>${data.barber}</td>
            <td>${data.periodDate} (${data.period})</td>
            <td>${data.hoursWorked}</td>
            <td>R ${data.baseSalary.toFixed(2)}</td>
            <td>R ${data.commissionAmt.toFixed(2)}</td>
            <td>R ${data.totalSalary.toFixed(2)}</td>
            <td>${data.status}</td>
            <td>
                <button class="action-btn" onclick="markPaid('${docSnap.id}')" 
                    ${data.status === 'paid' ? 'disabled' : ''}>
                    ${data.status === 'paid' ? 'Paid' : 'Mark Paid'}
                </button>
                <button class="action-btn" onclick="deleteSalary('${docSnap.id}')">Delete</button>
            </td>
        `;
        
        salaryTableBody.appendChild(tr);
    });
}

// Mark salary as paid
window.markPaid = async function(docId) {
    if (!confirm('Mark this salary as paid?')) return;

    try {
        await updateDoc(doc(db, "salaries", docId), {
            status: "paid"
        });

        alert('Salary marked as paid!');
        loadSalaries();
        
    } catch (error) {
        console.error("Error updating salary:", error);
        alert('Error updating salary');
    }
}

// Delete salary
window.deleteSalary = async function(docId) {
    if (!confirm('Delete this salary record?')) return;

    try {
        await deleteDoc(doc(db, "salaries", docId));
        alert('Salary record deleted!');
        loadSalaries();
        
    } catch (error) {
        console.error("Error deleting salary:", error);
        alert('Error deleting salary');
    }
}

// Load salaries when page opens
document.addEventListener('DOMContentLoaded', loadSalaries);