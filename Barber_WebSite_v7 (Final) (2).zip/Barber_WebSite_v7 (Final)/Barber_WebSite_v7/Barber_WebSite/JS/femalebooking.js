// femalebooking.js
import { db, auth } from "./Firebase.js";
import {
  doc,
  setDoc,
  getDocs,
  collection,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const bookingForm = document.getElementById("booking-form");
const dateInput = document.getElementById("appointment-date");
const timeInput = document.getElementById("appointment-time");
const locationSelect = document.getElementById("location");
const stylistSelect = document.getElementById("hairStylist");
const serviceSelect = document.getElementById("hairstyle");
const dyeSelect = document.getElementById("dye");

dateInput.valueAsDate = new Date();

async function generateAppointmentID() {
  const appointmentsRef = collection(db, "appointments");
  const q = query(appointmentsRef, orderBy("appointmentID", "desc"), limit(1));
  const snap = await getDocs(q);

  if (snap.empty) return "AP1001";

  // FIXED: Safe check for appointmentID field
  const lastDoc = snap.docs[0].data();
  const lastID = lastDoc.appointmentID;
  
  // If no appointmentID field exists or it's invalid, start from AP1001
  if (!lastID || !lastID.startsWith("AP")) {
    return "AP1001";
  }
  
  const number = parseInt(lastID.replace("AP", "")) + 1;
  return isNaN(number) ? "AP1001" : "AP" + number;
}

async function getServicePrice(serviceName) {
  const servicesRef = collection(db, "services");
  const q = query(servicesRef, where("name", "==", serviceName));
  const snap = await getDocs(q);
  if (snap.empty) return 0;
  return snap.docs[0].data().price;
}

async function getServiceDuration(serviceName) {
  const servicesRef = collection(db, "services");
  const q = query(servicesRef, where("name", "==", serviceName));
  const snap = await getDocs(q);
  if (snap.empty) return 30;
  return snap.docs[0].data().duration_min;
}

async function updateAvailableTimes() {
  const stylist = stylistSelect.value;
  const date = dateInput.value;
  const location = locationSelect.value;
  if (!stylist || !date || !location) return;

  const appointmentsRef = collection(db, "appointments");
  const q = query(
    appointmentsRef,
    where("barber", "==", stylist),
    where("appointmentDate", "==", date),
    where("location", "==", location)
  );
  const snap = await getDocs(q);
  const bookedTimes = snap.docs.map(doc => doc.data().appointmentTime);

  const times = [];
  for (let hour = 9; hour <= 17; hour++) {
    times.push(`${hour.toString().padStart(2, "0")}:00`);
    times.push(`${hour.toString().padStart(2, "0")}:30`);
  }

  timeInput.innerHTML = "";
  times.forEach(t => {
    const option = document.createElement("option");
    option.value = t;
    option.textContent = bookedTimes.includes(t) ? `${t} (Booked)` : t;
    if (bookedTimes.includes(t)) option.disabled = true;
    timeInput.appendChild(option);
  });
}

stylistSelect.addEventListener("change", updateAvailableTimes);
dateInput.addEventListener("change", updateAvailableTimes);
locationSelect.addEventListener("change", updateAvailableTimes);
window.addEventListener("DOMContentLoaded", updateAvailableTimes);

bookingForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const user = auth.currentUser;
  if (!user) {
    alert("⚠️ Please log in to book an appointment.");
    return;
  }

  const firstName = document.getElementById("first-name").value.trim();
  const lastName = document.getElementById("last-name").value.trim();
  const serviceName = serviceSelect.value;
  const stylist = stylistSelect.value;
  const location = locationSelect.value;
  const appointmentDate = dateInput.value;
  const appointmentTime = timeInput.value;
  const dye = dyeSelect.value;

  if (!firstName || !lastName || !serviceName || !stylist || !location || !appointmentDate || !appointmentTime) {
    alert("⚠️ Please fill in all required fields.");
    return;
  }

  try {
    const appointmentsRef = collection(db, "appointments");

    const conflictQuery = query(
      appointmentsRef,
      where("barber", "==", stylist),
      where("appointmentDate", "==", appointmentDate),
      where("appointmentTime", "==", appointmentTime),
      where("location", "==", location)
    );
    const conflictSnap = await getDocs(conflictQuery);
    if (!conflictSnap.empty) {
      alert(`❌ Sorry, ${stylist} is already booked at this time.`);
      updateAvailableTimes();
      return;
    }

    const appointmentID = await generateAppointmentID();

    const servicePrice = await getServicePrice(serviceName);
    const serviceDuration = await getServiceDuration(serviceName);
    const dyePrice = dye ? 50 : 0;
    const price = servicePrice + dyePrice;

    await setDoc(doc(db, "appointments", appointmentID), {
      appointmentID,
      userID: user.uid,
      customerName: `${firstName} ${lastName}`,
      serviceName,
      dye,
      barber: stylist,
      location,
      appointmentDate,
      appointmentTime,
      status: "Pending Payment",
      price,
      duration_min: serviceDuration,
      createdAt: serverTimestamp()
    });

    alert(`✅ Booking created! Appointment ID: ${appointmentID}`);
    bookingForm.reset();
    updateAvailableTimes();

    window.location.href = `Payment.html?appointmentID=${appointmentID}`;
  } catch (err) {
    console.error("Error saving booking:", err);
    alert("❌ Failed to save booking. Try again.");
  }
});