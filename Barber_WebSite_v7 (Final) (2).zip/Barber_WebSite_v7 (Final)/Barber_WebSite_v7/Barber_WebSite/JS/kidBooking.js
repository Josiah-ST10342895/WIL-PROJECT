// kidsbooking.js
import { db, auth } from "./Firebase.js";
import {
  doc,
  setDoc,
  getDocs,
  collection,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

// Wait for DOM to load before getting elements
document.addEventListener('DOMContentLoaded', function() {
  const bookingForm = document.getElementById("booking-form");
  const barberSelect = document.getElementById("barber");
  const dateInput = document.getElementById("appointment-date");
  const timeInput = document.getElementById("appointment-time");
  const locationSelect = document.getElementById("location");
  const serviceSelect = document.getElementById("haircut");
  const dyeSelect = document.getElementById("dye");

  // Debug: Check if elements are found
  console.log("Booking Form:", bookingForm);
  console.log("Barber Select:", barberSelect);
  console.log("Service Select:", serviceSelect);

  if (!bookingForm) {
    console.error("Booking form not found!");
    return;
  }

  if (dateInput) {
    dateInput.valueAsDate = new Date();
  }

  // Generate next appointmentID
  async function generateAppointmentID() {
    const appointmentsRef = collection(db, "appointments");
    const q = query(appointmentsRef, orderBy("appointmentID", "desc"), limit(1));
    const snap = await getDocs(q);

    if (snap.empty) return "AP1001";

    const lastDoc = snap.docs[0].data();
    const lastID = lastDoc.appointmentID;
    
    if (!lastID || !lastID.startsWith("AP")) {
      return "AP1001";
    }
    
    const number = parseInt(lastID.replace("AP", "")) + 1;
    return isNaN(number) ? "AP1001" : "AP" + number;
  }

  // Generate next childBookingID
  async function generateChildBookingID() {
    const childBookingRef = collection(db, "childBooking");
    const q = query(childBookingRef, orderBy("childBookingID", "desc"), limit(1));
    const snap = await getDocs(q);

    if (snap.empty) return "CB1001";

    const lastDoc = snap.docs[0].data();
    const lastID = lastDoc.childBookingID;
    
    if (!lastID || !lastID.startsWith("CB")) {
      return "CB1001";
    }
    
    const number = parseInt(lastID.replace("CB", "")) + 1;
    return isNaN(number) ? "CB1001" : "CB" + number;
  }

  // Get service price from services collection
  async function getServicePrice(serviceName) {
    const servicesRef = collection(db, "services");
    const q = query(servicesRef, where("name", "==", serviceName));
    const snap = await getDocs(q);
    if (snap.empty) {
      console.log("Service not found:", serviceName);
      return 0;
    }
    const price = snap.docs[0].data().price;
    console.log("Service price:", serviceName, price);
    return price;
  }

  // Get service duration from services collection
  async function getServiceDuration(serviceName) {
    const servicesRef = collection(db, "services");
    const q = query(servicesRef, where("name", "==", serviceName));
    const snap = await getDocs(q);
    if (snap.empty) {
      console.log("Service duration not found:", serviceName);
      return 30;
    }
    const duration = snap.docs[0].data().duration_min;
    console.log("Service duration:", serviceName, duration);
    return duration;
  }

  // Update available times based on barber, date, and location
  async function updateAvailableTimes() {
    if (!barberSelect || !dateInput || !timeInput || !locationSelect) return;
    
    const barber = barberSelect.value;
    const date = dateInput.value;
    const location = locationSelect.value;
    if (!barber || !date || !location) return;

    console.log("Updating times for:", barber, date, location);

    const appointmentsRef = collection(db, "appointments");
    const q = query(
      appointmentsRef,
      where("barber", "==", barber),
      where("appointmentDate", "==", date),
      where("location", "==", location)
    );
    const snap = await getDocs(q);
    const bookedTimes = snap.docs.map(doc => doc.data().appointmentTime);

    const times = [];
    for (let hour = 9; hour <= 17; hour++) {
      times.push(`${hour.toString().padStart(2, "0")}:00`);
      times.push(`${hour.toString().padStart(2, "0")}:30`);
    }

    timeInput.innerHTML = '<option value="">Select a time</option>';
    times.forEach(t => {
      const option = document.createElement("option");
      option.value = t;
      option.textContent = bookedTimes.includes(t) ? `${t} (Booked)` : t;
      if (bookedTimes.includes(t)) option.disabled = true;
      timeInput.appendChild(option);
    });
  }

  // Add event listeners if elements exist
  if (barberSelect) {
    barberSelect.addEventListener("change", updateAvailableTimes);
  }
  if (dateInput) {
    dateInput.addEventListener("change", updateAvailableTimes);
  }
  if (locationSelect) {
    locationSelect.addEventListener("change", updateAvailableTimes);
  }
  
  // Initial load
  setTimeout(updateAvailableTimes, 1000);

  // Handle form submission
  bookingForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    console.log("Form submitted!");

    const user = auth.currentUser;
    if (!user) {
      alert("⚠️ Please log in to book an appointment.");
      return;
    }

    const firstName = document.getElementById("first-name")?.value.trim();
    const lastName = document.getElementById("last-name")?.value.trim();
    const serviceName = serviceSelect?.value;
    const barber = barberSelect?.value;
    const location = locationSelect?.value;
    const appointmentDate = dateInput?.value;
    const appointmentTime = timeInput?.value;
    const dye = dyeSelect?.value || "None";

    console.log("Form data:", { firstName, lastName, serviceName, barber, location, appointmentDate, appointmentTime, dye });

    if (!firstName || !lastName || !serviceName || !barber || !location || !appointmentDate || !appointmentTime) {
      alert("⚠️ Please fill in all required fields.");
      return;
    }

    try {
      const appointmentsRef = collection(db, "appointments");

      // Check for conflicts
      const conflictQuery = query(
        appointmentsRef,
        where("barber", "==", barber),
        where("appointmentDate", "==", appointmentDate),
        where("appointmentTime", "==", appointmentTime),
        where("location", "==", location)
      );
      const conflictSnap = await getDocs(conflictQuery);
      if (!conflictSnap.empty) {
        alert(`❌ Sorry, ${barber} is already booked at this time.`);
        updateAvailableTimes();
        return;
      }

      // Generate IDs
      const appointmentID = await generateAppointmentID();
      const childBookingID = await generateChildBookingID();

      console.log("Generated IDs:", { appointmentID, childBookingID });

      // Get service price and duration
      const servicePrice = await getServicePrice(serviceName);
      const serviceDuration = await getServiceDuration(serviceName);
      const dyePrice = dye ? 50 : 0;
      const price = servicePrice + dyePrice;

      console.log("Price calculation:", { servicePrice, dyePrice, total: price });

      // 1. Create Appointment record
      await setDoc(doc(db, "appointments", appointmentID), {
        appointmentID,
        userID: user.uid,
        customerName: `${firstName} ${lastName}`,
        serviceName,
        dye,
        barber,
        location,
        appointmentDate,
        appointmentTime,
        status: "Pending Payment",
        price,
        duration_min: serviceDuration,
        createdAt: serverTimestamp()
      });

      // 2. Create ChildBooking record
      await setDoc(doc(db, "childBooking", childBookingID), {
        childBookingID,
        appointmentID: appointmentID,
        childFirstname: firstName,
        childLastname: lastName,
        dateOfBirth: "",
        serviceName,
        dye,
        barber,
        location,
        appointmentDate,
        appointmentTime,
        createdAt: serverTimestamp()
      });

      // Store for guardian page
      sessionStorage.setItem("appointmentID", appointmentID);
      sessionStorage.setItem("childBookingID", childBookingID);
      sessionStorage.setItem("childBooking", JSON.stringify({
        appointmentID,
        childBookingID,
        childFirstname: firstName,
        childLastname: lastName,
        serviceName,
        dye,
        barber,
        location,
        appointmentDate,
        appointmentTime
      }));

      alert(`✅ Child booking created! Appointment ID: ${appointmentID}`);
      bookingForm.reset();
      updateAvailableTimes();

      // Redirect to guardian page
      window.location.href = "KidGuardian.html";
    } catch (err) {
      console.error("Error saving booking:", err);
      alert("❌ Failed to save booking. Try again.");
    }
  });
});